waxClass{"PJView", UIView}
--{"要修改的类名",该类的类型}

function updateView(self)

    self:setBackgroundColor(UIColor:redColor())

end