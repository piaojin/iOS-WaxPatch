waxClass{"PJModel", NSObject}
--{"要修改的类名",该类的类型}

function prompt(self)

return "修改后"

end