require "ViewController"
require "PJView"
require "PJModel"
--需要修改的类全部在这边声明，并且在创建对应的类名.lua文件，文件中的内容即为该类要修改的内容